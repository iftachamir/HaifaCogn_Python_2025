# 1
def print1234():
	print(1)
	print(2)
	print(3)
	print(4)

def Hello(s):
	return("Hello, " + s)